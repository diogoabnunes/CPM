﻿using System.ComponentModel;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace PostByte {
  [ServiceContract]
  public interface IPostCert {
    [WebInvoke(Method = "POST", UriTemplate = "/SendCert", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
    [Description("Receives a certificate in base64 (string) format and returns other string with a description.")]
    [OperationContract]
    CertData SendCert(string cert);
  }

  [DataContract]
  public class CertData {
    [DataMember]
    public string subject;
    [DataMember]
    public string issuer;
    [DataMember]
    public string version;
    [DataMember]
    public string sdate;
    [DataMember]
    public string edate;
    [DataMember]
    public string thumb;
    [DataMember]
    public string serial;
    [DataMember]
    public string friendly;
    [DataMember]
    public string pkencoding;
    [DataMember]
    public string dlen;
  }
}
