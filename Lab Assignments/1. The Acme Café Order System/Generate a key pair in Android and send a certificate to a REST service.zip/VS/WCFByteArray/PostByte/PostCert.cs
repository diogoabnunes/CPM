﻿using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace PostByte {
  public class PostCert : IPostCert {
    public CertData SendCert(string cert) {
      X509Certificate2 c = new X509Certificate2(Encoding.ASCII.GetBytes(cert));
      CertData data = new CertData();

      data.subject = c.Subject;
      data.issuer = c.Issuer;
      data.version = c.Version.ToString();
      data.sdate = c.NotBefore.ToString();
      data.edate = c.NotAfter.ToString();
      data.thumb = c.Thumbprint;
      data.serial = c.SerialNumber;
      data.friendly = c.PublicKey.Oid.FriendlyName;
      data.pkencoding = c.PublicKey.EncodedKeyValue.Format(true);

      return data;
    }
  }
}
