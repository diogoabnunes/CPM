﻿using System;
using System.ServiceModel.Web;

namespace WCFByteArray {
  class Program {
    static void Main(string[] args) {
      WebServiceHost host = new WebServiceHost(typeof(PostByte.PostCert));
      host.Open();
      Console.WriteLine("Rest service running");
      Console.WriteLine("Press ENTER to stop the service");
      Console.ReadLine();
      host.Close();
    }
  }
}
