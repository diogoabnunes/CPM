package org.feup.apm.genkeysandsend;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.security.KeyPairGeneratorSpec;
import android.util.Base64;
import android.util.JsonReader;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.security.auth.x500.X500Principal;

public class MainActivity extends AppCompatActivity {
  final String TAG = "GenKeysAndSend";
  boolean hasKey;
  TextView tvKey, tvNoKey;
  EditText edAddr;
  PublicKey pub;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    tvNoKey = findViewById(R.id.tv_nokey);
    tvKey = findViewById(R.id.tv_pubkey);
    edAddr = findViewById(R.id.ed_addr);
    findViewById(R.id.bt_genkey).setOnClickListener((v)->genKeys());
    findViewById(R.id.bt_sendkey).setOnClickListener((v)->sendKey());
    findViewById(R.id.bt_showkey).setOnClickListener((v)->showKey());

    // See if we have already the keys and read them
    try {
      KeyStore ks = KeyStore.getInstance(Constants.ANDROID_KEYSTORE);
      ks.load(null);
      KeyStore.Entry entry = ks.getEntry(Constants.keyname, null);
      hasKey = (entry != null);
    }
    catch (Exception e) {
      hasKey = false;
    }
    tvNoKey.setText(hasKey?"Keys already generated":"No keys!");

    findViewById(R.id.bt_sendkey).setEnabled(hasKey);
    findViewById(R.id.bt_showkey).setEnabled(hasKey);
    findViewById(R.id.bt_genkey).setEnabled(!hasKey);
  }

  //
  // generate the user private/public keypair into the Android Keystore
  //
  void genKeys() {
    String text;

    try {
      Calendar start = new GregorianCalendar();
      Calendar end = new GregorianCalendar();
      end.add(Calendar.YEAR, 20);            // 20 years validity
      KeyPairGenerator kgen = KeyPairGenerator.getInstance(Constants.KEY_ALGO, Constants.ANDROID_KEYSTORE);
      AlgorithmParameterSpec spec = new KeyPairGeneratorSpec.Builder(this)
          .setKeySize(Constants.KEY_SIZE)
          .setAlias(Constants.keyname)                                       // the name of the key (common name) to retrieve it
          .setSubject(new X500Principal("CN=" + Constants.keyname))
          .setSerialNumber(BigInteger.valueOf(Constants.CERT_SERIAL))       // a serial number to the public key certificate
          .setStartDate(start.getTime())
          .setEndDate(end.getTime())
          .build();
      kgen.initialize(spec);
      KeyPair kp = kgen.generateKeyPair();
      pub = kp.getPublic();                                          // the corresponding public key in a Java class (PublicKey)
      hasKey = true;
    } catch (Exception e) {
      tvNoKey.setText(e.getMessage());
      return;
    }
    findViewById(R.id.bt_sendkey).setEnabled(true);
    findViewById(R.id.bt_showkey).setEnabled(true);
    findViewById(R.id.bt_genkey).setEnabled(false);
    tvNoKey.setText("Keys generated");
  }
  //
  // show the public key certificate in multiple formats (binary(DER), base64 string, text)
  //
  void showKey() {
    try {
      KeyStore ks = KeyStore.getInstance(Constants.ANDROID_KEYSTORE);
      ks.load(null);
      KeyStore.Entry entry = ks.getEntry(Constants.keyname, null);
      if (entry != null) {
        X509Certificate cert = (X509Certificate)((KeyStore.PrivateKeyEntry)entry).getCertificate();
        byte[] encCert = cert.getEncoded();     // certificate in DER format
        String strCert = cert.toString();       // certificate string description
        String b64Cert = Base64.encodeToString(encCert, Base64.NO_WRAP);    // transform into Base64 string (PEM format without the header and footer)

        String text = "Cert in DER (binary shown in Hex):"+ encCert.length + " bytes: " + byteArrayToHex(encCert) + "\n\nCert in PEM (b64:" + b64Cert.length() + " bytes): " + b64Cert + "\n\n" + strCert;
        tvKey.setText(text);

        // The base64 string with a header and a footer (is the PEM format)
        // printed in the Android Studio Log
        text = " \n" +                                  //begin in a new line
            // The content of a PEM format certificate:
            "-----BEGIN CERTIFICATE-----\n" +          // Header in PEM format
            Base64.encodeToString(encCert, Base64.DEFAULT) +                       // Certificate data in base64
            "-----END CERTIFICATE-----\n";             // Footer in PEM format
        Log.d(TAG, text);
      }
    }
    catch (Exception e) {
      tvNoKey.setText(e.getMessage());
    }
  }
  //
  // send the public key certificate in Base64 format (aka PEM - without header and footer) to a webservice
  //
  void sendKey() {
    X509Certificate cert;

    try {
      KeyStore ks = KeyStore.getInstance(Constants.ANDROID_KEYSTORE);
      ks.load(null);
      KeyStore.Entry entry = ks.getEntry(Constants.keyname, null);
      if (entry != null) {
        cert = (X509Certificate)((KeyStore.PrivateKeyEntry)entry).getCertificate();
        String b64Cert = Base64.encodeToString(cert.getEncoded(), Base64.NO_WRAP);    // transform into Base64 string (PEM format without the header and footer)
        String address = edAddr.getText().toString();
        if (address.length() > 0)
          new Thread(new SendKey(address, b64Cert)).start();
        else
          tvKey.setText("Supply the server IP address!");
      }
    }
    catch (Exception e) {
      tvNoKey.setText(e.getMessage());
    }
  }

  // transform a byte[] into a string with hexadecimal digits
  String byteArrayToHex(byte[] ba) {
    StringBuilder sb = new StringBuilder(ba.length * 2);
    for(byte b: ba)
      sb.append(String.format("%02x", b));
    return sb.toString();
  }

  //**************************************************************************
//Internal class to call REST POST operation SendCert

  private class SendKey implements Runnable {
    String address = null;
    String cert = null;

    SendKey(String baseAddress, String b64Cert) {
      address = baseAddress;
      cert = b64Cert;
    }

    @Override
    public void run() {
      URL url;
      HttpURLConnection urlConnection = null;

      try {
        url = new URL("http://" + address + ":5000/PostCert/SendCert");
        writeText("POST " + url.toExternalForm());
        urlConnection = (HttpURLConnection) url.openConnection();
        urlConnection.setDoOutput(true);
        urlConnection.setDoInput(true);
        urlConnection.setRequestMethod("POST");
        urlConnection.setRequestProperty("Content-Type", "application/json");
        urlConnection.setUseCaches(false);
        OutputStream out = urlConnection.getOutputStream();
        String payload = JSONObject.quote(cert);                       // JSON requires enclosing quotes
        appendText("\npayload: " + payload);
        out.write(payload.getBytes(Charset.forName("ISO-8859-1")));    // needs "ISO-8859-1" to not modify the char codes
        out.flush();
        out.close();

        // get response
        int responseCode = urlConnection.getResponseCode();
        if(responseCode == 200) {
          String response = readStream(urlConnection.getInputStream());   // a string is expected
          appendText("\n" + response);
        }
        else
          appendText("\nCode: " + responseCode);
      }
      catch (Exception e) {
        appendText(e.toString());
      }
      finally {
        if(urlConnection != null)
          urlConnection.disconnect();
      }
    }
  }

  private void writeText(final String text) {
    runOnUiThread(() -> tvKey.setText(text));
  }

  private void appendText(final String text) {
    runOnUiThread(() -> tvKey.setText(tvKey.getText() + "\n" + text));
  }

  private String readStream(InputStream in) {
    BufferedReader reader = null;
    StringBuilder response = new StringBuilder();

    try {
       reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
       String line;
       while ((line = reader.readLine()) != null)
         response.append(line);
    } catch (IOException e) {
      return e.getMessage();
    } finally {
      if (reader != null)
        try {
          reader.close();
        } catch (IOException e) {
          response.append(e.getMessage());
        }
    }
    return response.toString();
  }
}