This demo has an Android app + a .NET REST service for receiving a certificate with a public key

The Android app (GenKeysAndSend) generates a pair of 512 bit RSA private and public keys in the
Android Key Store.

The app then extracts and shows a certificate containing the public key.
Certificates are documents usually represented in one of two formats:
 - DER, which is a binary (byte[]) encoded format stored in files with .cer, .cert, or .crt extensions.
 - PEM, which is the previous binary encoding transformed into a base64 string with a header and a footer.

Certificates contain a lot of internal fields, identifying the owner, validity period, ..., including
the value of the public key (which has two numbers: modulus and exponent).

The app has buttons to:
  - generate the key pair (in the Android Key Store)
  - show the certificate in several formats (including showing some of the individual internal fields)
  - send the certificate (as a base64 string (PEM), but without the headers) to a POST REST request
      that should undertstand it and reply with a JSON object with some of its internal fields
It shows also the certificate in PEM format in the Logcat of Android Studio, which you can copy and paste,
in other applications or a file.

This demo contains also a REST service, implemented in .NET (VS project), that you shoud compile and run in
Windows in administrator mode.
It accepts a POST with the certificate as payload (in a base64 string), in the address:
http://<machine>:5000/PostCert/SendCert

The service reads the certificate and creates an object, in the .NET framework library (secutity API), representing it.
From that object, some of the internal fields are then read and put on a data object, that is transmitted
back as a JSON response.


