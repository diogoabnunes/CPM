package org.feup.apm.planetsfragments;

import android.app.Activity;
import android.app.Application;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;

public class MyApp extends Application {
  private MediaPlayer mp;
  private int pos = 0;

  @Override
  public void onCreate() {
    super.onCreate();
    registerActivityLifecycleCallbacks(new AppLifecycleTracker());
  }

  class AppLifecycleTracker implements Application.ActivityLifecycleCallbacks {
    private int numStarted = 0;

    @Override
    public void onActivityStarted(Activity activity) {
      Log.d("App", "Started");
      if (numStarted == 0) {
        mp = MediaPlayer.create(activity, R.raw.mars_exc);
        mp.seekTo(pos);
        mp.setLooping(true);
        mp.start();
      }
      numStarted++;
    }

    @Override
    public void onActivityStopped(Activity activity) {
      numStarted--;
      if (numStarted == 0) {
        pos = mp.getCurrentPosition();
        mp.stop();
        mp.release();
      }
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle bundle) {
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    @Override
    public void onActivityPaused(Activity activity) {
    }

    @Override
    public void onActivityResumed(Activity activity) {
    }

    @Override
    public void onActivityDestroyed(Activity activity) {
    }
  }
}
