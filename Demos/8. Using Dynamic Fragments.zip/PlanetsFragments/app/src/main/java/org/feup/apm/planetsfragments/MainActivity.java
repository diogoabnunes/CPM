package org.feup.apm.planetsfragments;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {
	public static final String TAG = "Planets";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
	}

	@Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.main_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == R.id.about) {
      Intent i = new Intent(this, AboutActivity.class);
      startActivity(i);
      return true;
    }
    else
      return super.onOptionsItemSelected(item);
  }

  public boolean isMultiPane() {
    return getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
  }

  /**
   * Helper function to show the details of a selected item, either by
   * displaying a fragment in-place in the current UI, or starting a
   * whole new activity in which is displayed.
   */
  public void showDetails(int index) {
    Log.v(TAG, "in MainActivity showDetails(" + index + ")");

    if (isMultiPane()) {
      // Check what fragment is shown, replace if needed.
      DetailsFragment details = (DetailsFragment) getFragmentManager().findFragmentById(R.id.details);
      if (details == null || details.getShownIndex() != index) {
        details = DetailsFragment.newInstance(index);           // Make new fragment to show this selection.
        // Execute a transaction, replacing any existing fragment inside the frame with the new one.
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.setCustomAnimations(R.animator.slide_in_left, R.animator.slide_out_right);
        //ft.setCustomAnimations(R.animator.bounce_in_down, R.animator.slide_out_right);
        //ft.setCustomAnimations(R.animator.fade_in, R.animator.fade_out);
        //ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.replace(R.id.details, details);
        ft.addToBackStack(TAG);
        ft.commit();
      }
    }
    else {
      // Otherwise we need to launch a new activity
      // but first empty the fragment stack
      getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
      Intent intent = new Intent();
      intent.setClass(this, DetailsActivity.class);
      intent.putExtra("index", index);
      startActivity(intent);
    }
  }
}
