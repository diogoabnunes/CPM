package org.feup.apm.ardemo;

import android.content.Context;
import android.hardware.Camera;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

@SuppressWarnings("deprecation")
public class CameraPreview extends SurfaceView implements SurfaceHolder.Callback {
	private SurfaceHolder holder;
	private Camera cam;
	private boolean inPreview;
	private MainActivity activity;

	public CameraPreview(Context context) {
		super(context);
		activity = (MainActivity) context;
		cam = null;
		inPreview = false;
		holder = getHolder();
		holder.addCallback(this);
		holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
	}

	@Override
	public void surfaceChanged(SurfaceHolder surfHolder, int format, int w, int h) {
		try {
			Camera.Parameters parameters = cam.getParameters();
			Camera.Size size = getBestPreviewSize(h, w, parameters); // h and w switched because we have a rotated cam

			if (size != null) {
				parameters.setPreviewSize(size.width, size.height);
				cam.setParameters(parameters);
			}
			activity.horAngle = cam.getParameters().getVerticalViewAngle();  //camera rotated
			cam.setDisplayOrientation(90);  // view the cam in portrait
			cam.startPreview();
			inPreview = true;
		}
    catch (Exception e){
    }
	}

	@Override
	public void surfaceCreated(SurfaceHolder surfHolder) {
		try {
			cam.setPreviewDisplay(holder);
		}
		catch (Throwable t) {
		}
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder arg0) {
	}
	
	public void stopPreview() {
		if (inPreview)
			cam.stopPreview();
		cam.release();
		cam = null;
		inPreview = false;
		setVisibility(INVISIBLE);  // destroys the Surface
	}
	
	public void open() {
		cam = Camera.open();
		setVisibility(VISIBLE);  // recreates the Surface
	}
	
  private Camera.Size getBestPreviewSize(int width, int height, Camera.Parameters parameters) {
		Camera.Size result=null;

		for (Camera.Size size : parameters.getSupportedPreviewSizes())
			if (size.width<=width && size.height<=height)
				if (result==null)
					result=size;
				else {
					int resultArea=result.width*result.height;
					int newArea=size.width*size.height;

					if (newArea>resultArea)
						result=size;
				}
		return result;
  }
}
