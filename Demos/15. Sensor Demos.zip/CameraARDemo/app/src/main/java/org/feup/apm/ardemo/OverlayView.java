package org.feup.apm.ardemo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.view.View;

public class OverlayView extends View {
	private Paint paint, p;
	public float x = 0.5f, heading;
	boolean draw = false;
	private MainActivity activity;
	
 	public OverlayView(Context context) {
		super(context);
		activity = (MainActivity) context;
		paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setColor(Color.RED);
		paint.setStyle(Style.FILL);
		paint.setTextAlign(Align.CENTER);
		paint.setTextSize(100);
		p = new Paint(Paint.ANTI_ALIAS_FLAG);
		p.setColor(Color.GREEN);
		p.setStyle(Style.FILL);
		p.setTextAlign(Align.LEFT);
		p.setTextSize(20);
	}
	
	@Override
    protected void onDraw(Canvas canvas) {
		//Canvas canvas = previewHolder.lockCanvas();
		canvas.drawText("HAngle = " + activity.horAngle + "  Head = " + heading, 10, 400, p);
		if (draw)
			canvas.drawText("N", canvas.getWidth()*x, 150, paint);
	    //previewHolder.unlockCanvasAndPost(canvas);
	}
	
	public void setDraw(boolean drw) {
		draw = drw;
	}
}
