package org.feup.apm.ardemo;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Surface;
import android.view.WindowManager;
import android.widget.FrameLayout;

import static java.lang.Math.PI;

@SuppressWarnings("deprecation")
public class MainActivity extends Activity implements SensorEventListener {
	private CameraPreview preview;
	private OverlayView overlay;
	public float horAngle;
	public boolean inPreview;
	private SensorManager sensorManager;
	int natural;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		inPreview = false;

		// Create the Preview and Overlay and set them as the content of our activity.
		preview = new CameraPreview(this);
		overlay = new OverlayView(this);
		FrameLayout frame = (FrameLayout) findViewById(R.id.cameraPreview);
		frame.addView(preview);
		frame.addView(overlay);
	}

	@Override
	protected void onResume() {
		super.onResume();
		natural = getDeviceDefaultOrientation();
		sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION), SensorManager.SENSOR_DELAY_NORMAL);
		preview.open();
	}

	@Override
	protected void onPause() {
		preview.stopPreview();
		sensorManager.unregisterListener(this);
		super.onPause();
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		float heading;

		if (event.sensor.getType() == Sensor.TYPE_ORIENTATION) {
			heading = event.values[0];
			if (natural == 1) {
			  heading -= 90.0f;
			  if (heading < 360.0f)
				heading += 360.0f;
			}
			overlay.heading = heading;
			if (heading > horAngle/2 && heading < (360.0f - horAngle/2))
				overlay.setDraw(false);
			else {
				if (heading <= horAngle/2)
					overlay.x = 0.5f - heading/horAngle;
				else
					overlay.x = 0.5f + (360.0f - heading)/horAngle;
				overlay.setDraw(true);
			}
			overlay.postInvalidate();
		}
	}

	public int getDeviceDefaultOrientation() {
		WindowManager windowManager =  (WindowManager) getSystemService(Context.WINDOW_SERVICE);
		Configuration config = getResources().getConfiguration();
		int rotation = windowManager.getDefaultDisplay().getRotation();

		if ( ((rotation == Surface.ROTATION_0 || rotation == Surface.ROTATION_180) &&
				config.orientation == Configuration.ORIENTATION_LANDSCAPE)
			|| ((rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270) &&
				config.orientation == Configuration.ORIENTATION_PORTRAIT)) {
			return 1;  // landscape
		}
		else {
			return 0; // portrait
		}
	}
}
