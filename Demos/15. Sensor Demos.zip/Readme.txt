This demo contains 3 Android projects using sensors in Android Studio format. You will need an actual device to see the demos working.

1. Sensors project
This app shows the list of sensors available on the device.
The list includes physical sensors and synthesized ones whose implementation is also present on the device.
The user can see in real time the measurements from some of these sensors and change the rate.
The list and measurement screens are implemented using two fragments in the same activity.

2. ShakeDetector project
The shake detector uses the linear acceleration sensor (which is a synthesized sensor that removes gravity from the accelerometer physical sensor measurements).
Whenever 4 acceleration samples surpass a threshold value in a 0.5 s period a shake is considered detected. For each detection a callback is called in a listener style.
In this app each shake detection toggles the activity background colour.

3. CameraARDemo project
In this app the phone back camera is put in real time preview mode and a graphic overlay is superposed with the camera image (this is the principle of augmented reality applications).
Using the orientation sensor, when the device is pointing north (azimuth = 0?) or nearby a 'N' is drawn on the overlay and the user knows that the image he sees on the screen is pointing north.
