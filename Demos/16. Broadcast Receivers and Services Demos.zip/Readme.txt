Demos with Brodacast Receivers and Services
===========================================

1. StandAloneReceiver and TestBroadcastReceiver

StandAloneReceiver contains a broadcast receiver that creates a notification when it executes.
Prior to Android API level 12 all broadcast receivers could be invoked even if their processes have never been started. After API level 12, broadcast receivers associated to custom intents (or even certain system intents), require that the process where the BR belongs to, has executed at least once (passing from a STOPPED/INSTALLED state to a process STARTED state). In order to garanty that, the app that contains a broadcast receiver can contain another Activity that will make the broadcast receiver operational (after that activity had runned at least once).
It is also possible to specify (with an additional flag in the intent) that never STARTED processes should also be considered, which TestBroadcastReceiver does.
TestBroadcastReceiver generates a broadcast intent to the previous broadcast receiver using a menu item. The broadcast receiver creates a notification associated with a pending intent (with action ACTION_DIAL) starting the dial application when clicked.
After API 26, calling Broadcast receivers between different applications is not possible (except for OS broadcasts). Scheduled jobs partially replaced that functionality.

2. SimpleServiceDemo and StandAloneService

SimpleServiceDemo has an Activity that invokes a service through an intent and the starService() method. This application contains also a local service component that can be invoked that way. The Activity can also invoke another service in another application using also startService() (and an implicit intent).
The local service or the remote one are selected by a radio button.
StandAloneService contains the remote service called by the previous activity in SimpleServiceDemo.
See in the SimpleServiceDemo activity the messages generated in the code of the client and the service.
Only for the purpose of transmitting such status messages, the StandAloneService uses a broadcast receiver registered dynamically on the client (SimpleServiceDemo).

3. StockQuoteService and StockQuoteClient

StockQuoteService contains only a service component that can be invoked through RPC style calls (binding). It defines an interface that can be obtained by bindService() from other activities. The interface methods are called using an inter-process mechanism and by marshalling the parameters and results between the processes (all types transferred should be Parcelable). The interface and its methods must be described in an interface description language called AIDL (Android Interface Description Language).
StockQuoteClient is an application containing an activity that is the client of the previous service, binding and invoking its method. In this case (its not mandatory) the call is asynchronous (oneway AIDL defined interfaces), returning immediately, with the client defining also an interface callback through AIDL, and letting the remote call, when complete, call this callback in the client. You can see in the client, the evolution of the calls in a message log, where messages from the service are also transmitted using a broadcast receiver.

4. Alarm Demo

Creates alarms that repeat and are delivered through a Broadcast receiver, even if the app is not running. Setting and canceling are done in the app menu.
