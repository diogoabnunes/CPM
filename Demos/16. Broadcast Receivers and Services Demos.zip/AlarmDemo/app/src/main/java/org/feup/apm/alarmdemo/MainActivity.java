package org.feup.apm.alarmdemo;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {
  Intent alrmIntent;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu)
  {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.menu_main, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    alrmIntent = new Intent(this, AlarmReceiver.class);
    AlarmManager alManager = (AlarmManager)getSystemService(ALARM_SERVICE);
    switch (item.getItemId()) {
      case R.id.alarm1:
        alrmIntent.putExtra("message", "Alarm 1");
        alrmIntent.putExtra("type", 1);
        PendingIntent pi1 = PendingIntent.getBroadcast(this, 1, alrmIntent, 0);
        alManager.setExact(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), pi1);
        break;
      case R.id.alarm2:
        alrmIntent.putExtra("message", "Alarm 2");
        alrmIntent.putExtra("type", 2);
        PendingIntent pi2 = PendingIntent.getBroadcast(this, 2, alrmIntent, 0);
        alManager.setExact(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), pi2);
        break;
      case R.id.cancel1:
        PendingIntent pic1 = PendingIntent.getBroadcast(this, 1, alrmIntent, 0);
        alManager.cancel(pic1);
        break;
      case R.id.cancel2:
        PendingIntent pic2 = PendingIntent.getBroadcast(this, 2, alrmIntent, 0);
        alManager.cancel(pic2);
        break;
    }
    return true;
  }
}
