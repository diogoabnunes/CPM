package org.feup.apm.alarmdemo;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class AlarmReceiver extends BroadcastReceiver {

  @Override
  public void onReceive(Context context, Intent intent) {
    String message = intent.getStringExtra("message");
    int type = intent.getIntExtra("type", 1);
    displayNotificationMessage(context, message, type);

    AlarmManager al = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
    PendingIntent pi = PendingIntent.getBroadcast(context, type, intent, 0);
    if (type == 1)
      al.setExact(AlarmManager.RTC_WAKEUP, System.currentTimeMillis()+10*1000, pi);
    else
      al.setExact(AlarmManager.RTC_WAKEUP, System.currentTimeMillis()+15*1000, pi);
  }

  private void displayNotificationMessage(Context context, String message, int id) {
    NotificationManager notificationMgr;
    notificationMgr = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

    Notification notification = new Notification.Builder(context)
        .setSmallIcon(android.R.drawable.star_on)
        .setContentTitle("AlarmNotification")
        .setContentText(message)
        .setSound(Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.apple_ring))
        .build();
    notificationMgr.notify(id, notification);
  }
}
