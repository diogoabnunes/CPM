package org.feup.apm.IMEDemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;

public class IMEDemoActivity extends Activity
{
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
		setContentView(R.layout.main);
	}
}