package org.feup.apm.view2dcircle;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

public class GraphicsView extends View {
  private static final String QUOTE = "Now is the time for all good men to come to the aid of their country.";
  private final Path circle;
  private final Paint cPaint;
  private final Paint tPaint;


  public GraphicsView(Context context) {
    super(context);
    circle = new Path();
    cPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    cPaint.setStyle(Paint.Style.STROKE);
    cPaint.setColor(Color.LTGRAY);
    cPaint.setStrokeWidth(3);
    tPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    tPaint.setStyle(Paint.Style.FILL_AND_STROKE);
    tPaint.setColor(Color.BLACK);
    tPaint.setTextSize(40f);
    setBackgroundResource(R.drawable.background);
  }

  @Override
  protected void onSizeChanged(int wd, int hg, int oldw, int oldh) {
    super.onSizeChanged(wd, hg, oldw, oldh);
    float min = Math.min(wd, hg);
    circle.addCircle(wd / 2.0f, hg / 2.0f, 0.4f*min, Path.Direction.CW);
  }

  @Override
  protected void onDraw(Canvas canvas) {
    canvas.drawPath(circle, cPaint);
    canvas.drawTextOnPath(QUOTE, circle, 0, 40, tPaint);
  }
}
