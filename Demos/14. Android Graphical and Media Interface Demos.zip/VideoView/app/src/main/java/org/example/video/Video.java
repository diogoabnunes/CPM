package org.example.video;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;

public class Video extends Activity {
  VideoView video;
  TextView path;
  LinearLayout ll;
  Uri videoFile;

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);
    video = (VideoView) findViewById(R.id.video);
    path = (TextView) findViewById(R.id.textView);
    ll = (LinearLayout) findViewById(R.id.first);
    video.setVisibility(View.GONE);
    videoFile = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.bunny);
    path.setText(videoFile.toString());
  }

  public void onBtnPlay(View v) {
    ll.setVisibility(View.GONE);
    video.setVisibility(View.VISIBLE);
    video.setVideoURI(videoFile);
    video.requestFocus();
    video.start();
  }
}
