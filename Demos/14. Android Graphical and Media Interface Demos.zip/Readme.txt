Android virtual keyboard, graphic views, and media demos
========================================================

IMEDemo
-------
Shows several EditText views in a layout with different virtual keyboard configurations.
The virtual keyboard associated with an EditText view can be configured using the EditText
view properties: android:inputType and android:imeOptions.

View2DCircle
------------
Creates a custom view (class derived from View) where a background, circle and text and
drawn directly on the View Canvas.

BouncyBall
----------
Uses a custom view with an image background and where a small bitmap (a ball) is drawn
periodically with small position increments, resulting on an animation.
The View Invalidate() method (which causes onDraw() to be called on the UI thread) is called
from an independent thread.

Touch2DCircle
-------------
Draws a circle in a custom view in response to a touch low level event detected on the view.
The circle's color can be selected from a menu.
Also illustrates how to insert drawings in a string using a SpannableString, and presented
as items on the menu.

OpenGL
------
Illustrates the use of OpenGLES library to create and animate a 3D scene.
The screne is simply a cube with semi-transparent and image texture on the faces.
Between the generated frames the cube is rotated around two of its axes.

Audio
-----
Illustrates how to play short audio files in response to key press events in an activity.
The audio files are included in the resources (res) raw subdirectory and accessed as files.
The audio is played using a MediaPlayer object from the Android Framework library.

VideoView
---------
Ilustrates how display and play a video on the screen. The video is shown on the pre-defined
view VideoView, inserted on the layout.
Yhe video file is included on the .apk as a res/raw resource, but could also be obtained from
the Android file system (e.g. on a SD card), or even downloaded from the internet using a URL.
