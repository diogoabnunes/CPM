package org.feup.apm.bounce;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;

public class BounceActivity extends Activity {
  Thread myRefreshThread = null;
  BounceView myBounceView = null;

  @Override
  public void onCreate(Bundle icicle) {
    super.onCreate(icicle);
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    myBounceView = new BounceView(this);
    setContentView(myBounceView);
    new Thread(new RefreshRunner()).start();
  }

  class RefreshRunner implements Runnable {
    public void run() {
      while (!Thread.currentThread().isInterrupted()) {
        try {
          Thread.sleep(100);
        }
        catch (InterruptedException e) {
          Thread.currentThread().interrupt();
        }
        runOnUiThread(new Runnable() {
          @Override
          public void run() {
            myBounceView.invalidate();
          }
        });
      }
    }
  }
}