package org.feup.apm.bounce;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.view.KeyEvent;
import android.view.View;

public class BounceView extends View {
  protected Drawable mySprite;
  protected Point mySpritePos = new Point(0, 0);
  protected int incr = 10;
  protected enum HorizontalDirection {
    LEFT, RIGHT
  }
  protected enum VerticalDirection {
    UP, DOWN
  }
  protected HorizontalDirection myXDirection = HorizontalDirection.RIGHT;
  protected VerticalDirection myYDirection = VerticalDirection.UP;

  public BounceView(Context context) {
    super(context);
    mySprite = getResources().getDrawable(R.drawable.world);
    setBackgroundResource(R.drawable.android);
    setFocusable(true);
    setFocusableInTouchMode(true);
  }
  
  @Override
  public boolean onKeyDown(int keyCode, KeyEvent event) {
    switch (keyCode) {
      case KeyEvent.KEYCODE_DPAD_UP:
      case KeyEvent.KEYCODE_VOLUME_UP:
        if (incr < 20)
          incr++;
        break;
      case KeyEvent.KEYCODE_DPAD_DOWN:
      case KeyEvent.KEYCODE_VOLUME_DOWN:
        if (incr > 1)
          incr--;
        break;
      default:
        return super.onKeyDown(keyCode, event);
    }
    return true;
  }

  @Override
  protected void onDraw(Canvas canvas) {
    mySprite.setBounds(mySpritePos.x, mySpritePos.y, mySpritePos.x + 50, mySpritePos.y + 50);

    if (mySpritePos.x >= getWidth() - mySprite.getBounds().width())
      myXDirection = HorizontalDirection.LEFT;
    else if (mySpritePos.x <= 0)
      myXDirection = HorizontalDirection.RIGHT;

    if (mySpritePos.y >= getHeight() - mySprite.getBounds().height())
      myYDirection = VerticalDirection.UP;
    else if (this.mySpritePos.y <= 0)
        this.myYDirection = VerticalDirection.DOWN;

    if (myXDirection == HorizontalDirection.RIGHT)
      mySpritePos.x += incr;
    else
      mySpritePos.x -= incr;

    if (myYDirection == VerticalDirection.DOWN)
      mySpritePos.y += incr;
    else
      mySpritePos.y -= incr;

    mySprite.draw(canvas);
  }
}
