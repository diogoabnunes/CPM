Flutter Demos
=============

three_dogs
----------
A simple Flutter application using only StatelessWidget classes.
It builds a static page.

flutter_switch
--------------
A Flutter application with a StatefullWidget class.
From an user interaction, the state changes, and the Widget tree is rebuilt.

startup_namer
-------------
A demo with an 'infinite' scrollable listview widget.
When the user scrolls up, new items are generated, and shown at the bottom of the list.

flutter-mvcs-hello-world
------------------------
Illustrates with a simple demo the mvc+s pattern for Flutter applications.
See the article "Flutter: State Management using an MVC+S Architecture" at
https://blog.gskinner.com/archives/2020/09/flutter-state-management-with-mvcs.html
