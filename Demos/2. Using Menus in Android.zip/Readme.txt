StandardMenu
  Shows a menu with a submenu and an item with an icon in the ActionBar.
  It has also a context menu associated with the TextBox in the main screen.

OldStyleMenu
  Menu, submenu and context menu in apps for API 10 or before.
  Only works on devices with soft buttons (a menu button will appear) or with hard buttons including
  a menu button.
  On a google emulator without soft buttons use ctrl-M for emulating a hard menu button.