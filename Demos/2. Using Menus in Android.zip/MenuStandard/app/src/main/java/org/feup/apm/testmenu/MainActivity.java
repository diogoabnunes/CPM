package org.feup.apm.testmenu;

import android.app.Activity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity {
  TextView tv = null;
	
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    tv = (TextView) findViewById(R.id.textViewId);
    tv.setText("Test Menus:");
    registerForContextMenu(tv);
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) 
  {	
    MenuInflater inflater = getMenuInflater(); //from activity
    inflater.inflate(R.menu.my_menu, menu);
  	return true;
  }
  
  @Override
  public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
    new MenuInflater(this).inflate(R.menu.context, menu);
  }
  
  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
	  appendMenuItemText(item);
  	if (item.getItemId() == R.id.menu_clear)
  	  emptyText();
  	return true;
  }
  
  @Override
  public boolean onContextItemSelected(MenuItem item) {
    appendMenuItemText(item);
    return true;
  }
  
  private void appendMenuItemText(MenuItem menuItem) {
  	String title = menuItem.getTitle().toString();
   	tv.setText(tv.getText() + "\n" + title + ":" + menuItem.getItemId());
  }

  private void emptyText() {
    tv.setText("Test Menus:");
  }
}
