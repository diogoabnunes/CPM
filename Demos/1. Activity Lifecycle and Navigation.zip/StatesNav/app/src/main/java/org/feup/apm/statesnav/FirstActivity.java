package org.feup.apm.statesnav;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class FirstActivity extends Activity implements View.OnClickListener {
  private final String tag = "StatesNav";
  private int state = 0;
  TextView tv;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    Log.i(tag, "onCreate()");
    setContentView(R.layout.activity_first);
    tv = (TextView) findViewById(R.id.tv1);
    findViewById(R.id.bt1).setOnClickListener(this);
  }

  @Override
  protected void onRestart() {
    super.onRestart();
    Log.i(tag, "onRestart()");
  }

  @Override
  protected void onStart() {
    super.onStart();
    Log.i(tag, "onStart()");
  }

  @Override
  protected void onResume() {
    super.onResume();
    tv.setText(String.format("state = %d", state));
    Log.i(tag, "onResume()");
  }

  @Override
  protected void onRestoreInstanceState(Bundle savedInstanceState) {
    super.onRestoreInstanceState(savedInstanceState);
    Log.i(tag, "onRestoreInstanceState()");
    state = savedInstanceState.getInt("State");
  }

  @Override
  protected void onPause() {
    super.onPause();
    Log.i(tag, "onPause()");
  }

  @Override
  protected void onStop() {
    super.onStop();
    Log.i(tag, "onStop()");
  }

  @Override
  protected void onDestroy() {
    super.onDestroy();
    Log.i(tag, "First onDestroy()");
  }

  @Override
  protected void onSaveInstanceState(Bundle outState) {
    Log.i(tag, "onSaveInstanceState()");
    outState.putInt("State", state);
    super.onSaveInstanceState(outState);
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.menu_first, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    int id = item.getItemId();
    switch (id) {
      case R.id.action_second:
        Intent second = new Intent(this, SecondActivity.class);
        startActivity(second);
        return true;
      case R.id.action_finish:
        finish();
        return true;
    }
    return super.onOptionsItemSelected(item);
  }

  @Override
  public void onClick(View view) {
    state = 1;
    tv.setText("state = " + state);
  }
}
