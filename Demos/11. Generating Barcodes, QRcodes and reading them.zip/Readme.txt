Demos using the Google zxing library with apps to read and generate optical codes.
(Android Studio 3.6.1 + gradle 6.2.2)

There three Android applications:

ScanQR
======
Scans and show the messages read from QRcodes and barcodes.
It uses the scanning activity of another app through an implicit intent,
calling startActivityForResult().
If the other app is not installed on the device it asks for installation using
the Google Play Store (apps in play store have a special URL: market://...)

BarcodeZX
=========
Uses the zxing library to generate a standard barcode (UPC-A) from an
11 digit value (it adds automatically the 12th digit which is an error detection digit).
You can see that the code generated comes as a BitMatrix where each value indicates
foreground or background.
To be displayed, it must be transformed into a bitmap.

QRcodeZX
========
The same as the previous, but generating a QR code to represent a String message,
which is encoded as an array of bytes into the 2D bitmap code.
Experiment with different message sizes, from a few tens of characters through near
1000 characters. Observe the QR code shape change with the message size.
QR codes contain some redundancy, allowing some error correction if optical
acquisition errors occur.