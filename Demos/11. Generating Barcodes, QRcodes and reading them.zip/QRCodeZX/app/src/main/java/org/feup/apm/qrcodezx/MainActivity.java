package org.feup.apm.qrcodezx;

import android.graphics.Bitmap;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;

public class MainActivity extends AppCompatActivity {
  ImageView qrCodeIv;
  TextView errorTv;
  EditText edMessage;
  public final static int IMAGE_SIZE=540;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    edMessage = findViewById(R.id.ed_message);
    qrCodeIv = findViewById(R.id.img_qr_code);
    errorTv = findViewById(R.id.tv_error);
    findViewById(R.id.bt_generate).setOnClickListener((v) -> new Thread(new convertToQR(edMessage.getText().toString())).start());
  }

  class convertToQR implements Runnable {
    String content;

    convertToQR(String value) {
      content = value;
      errorTv.setText("");
    }

    @Override
    public void run() {
      final Bitmap bitmap;

      bitmap = encodeAsBitmap(content);
      runOnUiThread(()->qrCodeIv.setImageBitmap(bitmap));
    }
  }

  Bitmap encodeAsBitmap(String str) {
    BitMatrix result;
    try {
      result = new MultiFormatWriter().encode(str, BarcodeFormat.QR_CODE, IMAGE_SIZE, IMAGE_SIZE, null);
    }
    catch (Exception exc) {
      runOnUiThread(()->errorTv.setText(exc.getMessage()));
      return null;
    }
    int w = result.getWidth();
    int h = result.getHeight();
    int[] pixels = new int[w * h];
    for (int line = 0; line < h; line++) {
      int offset = line * w;
      for (int col = 0; col < w; col++) {
        pixels[offset + col] = result.get(col, line) ? getResources().getColor(R.color.colorPrimary):getResources().getColor(R.color.white);
      }
    }
    Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
    bitmap.setPixels(pixels, 0, w, 0, 0, w, h);
    return bitmap;
  }
}
