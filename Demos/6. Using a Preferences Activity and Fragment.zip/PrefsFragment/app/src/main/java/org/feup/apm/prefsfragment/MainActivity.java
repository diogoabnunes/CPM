package org.feup.apm.prefsfragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.main_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    int id = item.getItemId();
    if (id == R.id.mn_settings) {
      Intent intent = new Intent(this, SettingsActivity.class);
      startActivity(intent);
      return true;
    }
    return super.onOptionsItemSelected(item);
  }

  @Override
  public void onStart() {
    super.onStart();
    showUserSettings();
  }

  private void showUserSettings() {
    SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
    String prefs;
    boolean dependent;

    prefs = "\n Checkbox Pref: " + sharedPrefs.getBoolean("checkbox_preference", false);
    prefs += "\n String Pref: " + sharedPrefs.getString("edittext_preference", "");
    prefs += "\n List Pref: " + sharedPrefs.getString("list_preference", "");
    prefs += "\n Parent checkbox: " + (dependent = sharedPrefs.getBoolean("parent_checkbox_preference", false));
    if (dependent)
      prefs += "\n Child checkbox: " + sharedPrefs.getBoolean("child_checkbox_preference", false);
    prefs += "\n Switch in another screen: " + sharedPrefs.getBoolean("next_screen_checkbox_preference", false);

    TextView settingsTextView = findViewById(R.id.tv_values);
    settingsTextView.setText(prefs);
  }
}
