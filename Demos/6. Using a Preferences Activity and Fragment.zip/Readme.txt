This file contains two AS project demos illustrating the use of preferences.
Preferences are a set of values (settings) that can be changed by the user
and consulted at run-time to influence the functionality of the app.
Android provides the consulting and updating interface automatically, and
persists the values in a file within the app directory in the device.

In run-time the app can retrieve the settings values through the SharedPreferences
object, returned by the system service PreferenceManager.

PreferencesDemo
===============

This app uses the classical way to manage the app settings.
Those are defined in a resource stored in the res/xml directory.
The Android framework contains the specialized Activity derived class
named PreferenceActivity.
This Activity contains all the functionality to display and change the
preferences values. When it is destroyed the values are persisted.

PrefsFragment
=============

In more recent versions the framework library also defined a fragment
containing the same functionality of the PreferenceActivity. The use of
the PreferenceFragment inside some Activity is preferable as it manages
automatically the screen rotations.