package org.feup.apm.preferencesdemo;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends Activity {
  private static final int RESULT_PREFERENCES = 1;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    showUserSettings();
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.main, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    int id = item.getItemId();
    if (id == R.id.action_settings) {
      Intent intent = new Intent(this, UserSettingsActivity.class);
      startActivityForResult(intent, RESULT_PREFERENCES);
      return true;
    }
    return super.onOptionsItemSelected(item);
  }
  
  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (requestCode == RESULT_PREFERENCES)
      showUserSettings();
  }

  private void showUserSettings() {
    SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
    String prefs;

    prefs = "\n Username: " + sharedPrefs.getString("prefUsername", "NULL");
    prefs += "\n Crash report: " + sharedPrefs.getBoolean("prefSendReport", false);
    prefs += "\n Include warnings: " + sharedPrefs.getBoolean("prefIncludeWarnings", false);
    prefs += "\n Sync Frequency: " + sharedPrefs.getString("prefSyncFrequency", "NULL");
    TextView settingsTextView = (TextView) findViewById(R.id.textUserSettings);
    settingsTextView.setText(prefs);
  }
}
