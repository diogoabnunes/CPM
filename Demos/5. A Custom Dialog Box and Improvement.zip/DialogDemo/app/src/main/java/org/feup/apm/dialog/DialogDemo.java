package org.feup.apm.dialog;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.os.Bundle;
import android.widget.TextView;

public class DialogDemo extends AppCompatActivity implements View.OnClickListener, GetNameDialog.GetNameDialogResult {
  private TextView tv;
  private GetNameDialog dialog;

  /** Called when the activity is first created. */
  @Override
  public void onCreate(Bundle savedInstanceState) {
  	super.onCreate(savedInstanceState);
  	setContentView(R.layout.main);
    findViewById(R.id.button).setOnClickListener(this);
  	tv = findViewById(R.id.name);
  }

  public void onClick(View v) {
    if (v.getId() == R.id.button) {
      dialog = new GetNameDialog(this, getString(R.string.initial_name));
      dialog.show();
    }
  }

  /* dialog interface for communicating back */
  public void transferName(String name) {
    tv.setText("Hello, " + name + "!");
  }
}