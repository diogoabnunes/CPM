package org.feup.apm.dialog;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatDialog;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.EditText;

public class GetNameDialog extends AppCompatDialog implements View.OnClickListener {
  public interface GetNameDialogResult {
    void transferName(String name);
  }

  EditText edt;
  String initialHint;

  GetNameDialog(Context context, String init) {
	  super(context);
	  setTitle(R.string.dialog_title);
    setOwnerActivity((Activity)context);
    initialHint = init;
  }

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.dialog);
    getWindow().setLayout(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);

    /* initialize dialog from parameters obtained in the constructor */
	  edt = findViewById(R.id.yourname);
	  edt.setHint(initialHint);

    findViewById(R.id.getnameokbutton).setOnClickListener(this);
  }

  /* dialog button listener */
  public void onClick(View view) {
    /* transfer the results to activity (should implement the interface) */
    ((GetNameDialogResult)getOwnerActivity()).transferName(edt.getText().toString());
    dismiss();
  }
}
