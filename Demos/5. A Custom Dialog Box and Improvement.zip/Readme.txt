DialogDemo
==========

A standard custom dialog application.
Initialization data is transported when the dialog constructor is called.
The dialog defines a Java interface for transmitting results to the calling activity.
The activity that uses the dialog implements the interface for receiveing those results.
The dialog class implements all the listeners that result from the user interaction in the dialog layout.

See what happens when the user rotates the device with the dialog displayed.
This applicatin derives from a AppCompactActivity

DialogFragmentDemo
==================

In this app there is an intermediate class derived from fragment.
The activity builds and displays the dialog using the fragment.
Fragments are retained when the device is rotated.
All the rest is similar to the previous app.

Try to rotate the screen when the dialog is already displayed.
This one derives from a plain activity and uses Theme.Holo directly.