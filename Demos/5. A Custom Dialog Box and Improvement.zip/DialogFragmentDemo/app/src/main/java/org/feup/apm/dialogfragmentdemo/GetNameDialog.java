package org.feup.apm.dialogfragmentdemo;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.EditText;

public class GetNameDialog extends Dialog implements OnClickListener{
  public interface GetNameDialogListener {
    void onDoneClick(GetNameDialog dlg);
  }
  
  private String initialHint;
  private GetNameDialogListener listener;
  EditText edt;

  GetNameDialog(Context context, String init) {
	  super(context);
	  setTitle(R.string.dialog_title);
    setOwnerActivity((Activity)context);
    initialHint = init;
  }
  
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.dialog);
    getWindow().setLayout(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
    edt = findViewById(R.id.yourname);
    edt.setHint(initialHint);
	  listener = (GetNameDialogListener) getOwnerActivity();
    findViewById(R.id.getnameokbutton).setOnClickListener(this);
  }

  /* for the dialog button */
  @Override
  public void onClick(View v) {
    listener.onDoneClick(this);
    dismiss();
  }
}
