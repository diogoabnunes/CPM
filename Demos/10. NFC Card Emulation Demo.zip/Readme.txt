This pair of apps demonstrate the ability of Android to simulate NFC SmartCards in
software (using the Card Emulation mode of NFC).
SmartCards contain applets that can accept commands (in byte APDU format) generating
replies if recognized. These commands and replies are transmitted in a serial line
(with the standard smart card connector) or using a NFC channel.
Each applet has an associated AID (a 5 to 13 byte number) and the first operation
for using it should be a selectAID command ...

NFCCardEmulator
===============

Android allows the simulation of a smartcard applet in a special service that will work
with the NFC controller. That service should derive from HostApduService. The associated
AID is defined in a XML resource (in the res/xml directory).
In this simple example the applet, when selected, returns imediatelly a number
(representing a card number, that can be changed and persisted in the Android
application Activity).
The simple installation of the application (with the phone NFC enabled), makes the
device respond to NFC readers that select the emulated applet, as if it was a physical
SmartCard.

NFCCardReader
=============

Implements a reader of NFC replies coming from IsoDep SmartCards (as the one emulated
in the previous app). After detecting the presence of the card (NFC channel established)
it emits the selectAID command (using the same AID as the one associated with the applet
emulated in the previous app), and reads the reply. If the reply is valid, it shows the
card number contained in it.

The two previous apps should be installed in different phones and require API 19 or later
and support from the NFC hardware (not all phones with NFC are capable of working in
Card Emulation mode).