package org.feup.apm.nfccardemulator;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.widget.TextView;

class AccountStorage {
  private static final String PREF_ACCOUNT_NUMBER = "account_number";
  private static final String DEFAULT_ACCOUNT_NUMBER = "00000000";
  private static String account = null;
  private static final Object accountLock = new Object();

  static void setAccount(Context c, TextView tv, String s) {
    synchronized(accountLock) {
      String state = (String)tv.getText();
      tv.setText(String.format(c.getString(R.string.tv_state_template) ,state, s));
      SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(c);
      prefs.edit().putString(PREF_ACCOUNT_NUMBER, s).apply();
      account = s;
    }
  }

  static String getAccount(Context c) {
    synchronized (accountLock) {
      if (account == null) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(c);
        account = prefs.getString(PREF_ACCOUNT_NUMBER, DEFAULT_ACCOUNT_NUMBER);
      }
      return account;
    }
  }
}
