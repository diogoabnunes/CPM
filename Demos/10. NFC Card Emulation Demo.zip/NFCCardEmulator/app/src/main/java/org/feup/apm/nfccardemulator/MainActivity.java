package org.feup.apm.nfccardemulator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
  TextView tv_state;
  EditText ed_account;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    tv_state = findViewById(R.id.text_output);
    tv_state.setText(R.string.tv_state_ready);
    ed_account = findViewById(R.id.card_account_field);
    ed_account.setText(AccountStorage.getAccount(this));
    findViewById(R.id.button_save).setOnClickListener(this);
  }

  @Override
  public void onClick(View view) {
    String accNr = ed_account.getText().toString();
    int len = accNr.length();
    if (len < 8) {
      String res = "";
      for (int k = 0; k < 8 - len; k++)
        res += "0";
      accNr = res + accNr;
    }
    else if (len > 8)
      accNr = accNr.substring(0, 8);
    AccountStorage.setAccount(this, tv_state, accNr);
    ed_account.setText(AccountStorage.getAccount(this));
  }
}
