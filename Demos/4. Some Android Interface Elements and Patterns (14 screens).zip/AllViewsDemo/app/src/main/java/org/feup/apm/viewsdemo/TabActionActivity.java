package org.feup.apm.viewsdemo;

import android.os.Bundle;
import androidx.fragment.app.FragmentTransaction;
import androidx.appcompat.app.ActionBar;
import android.view.View;
import android.widget.AnalogClock;
import android.widget.Button;
import android.widget.Toast;

public class TabActionActivity extends BaseActivity implements ActionBar.TabListener {
  AnalogClock clock;
  Button button;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_tab_action);
    super.createDrawer();
    ActionBar aBar = getSupportActionBar();
    if (aBar != null) {
      aBar.setTitle(R.string.act10_name);
      aBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
    }

    clock = findViewById(R.id.analogClock1);
    button = findViewById(R.id.button1);
    button.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        Toast.makeText(TabActionActivity.this, "Button pressed", Toast.LENGTH_LONG).show();
      }
    });

    ActionBar.Tab tab = aBar.newTab();
    tab.setText("Clock");
    tab.setTabListener(this);
    aBar.addTab(tab);

    tab = aBar.newTab();
    tab.setText("Button");
    tab.setTabListener(this);
    aBar.addTab(tab);
  }

  @Override
  public void onTabReselected(ActionBar.Tab tab, FragmentTransaction ft) {
  }

  @Override
  public void onTabSelected(ActionBar.Tab tab, FragmentTransaction ft) {
    switch (tab.getPosition()) {
      case 0:
        clock.setVisibility(View.VISIBLE);
        break;
      case 1:
        button.setVisibility(View.VISIBLE);
        break;
    }
  }

  @Override
  public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction ft) {
    switch (tab.getPosition()) {
      case 0:
        clock.setVisibility(View.INVISIBLE);
        break;
      case 1:
        button.setVisibility(View.INVISIBLE);
        break;
    }
  }
}
