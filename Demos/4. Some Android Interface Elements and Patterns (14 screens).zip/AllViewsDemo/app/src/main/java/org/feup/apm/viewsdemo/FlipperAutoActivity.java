package org.feup.apm.viewsdemo;

import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.widget.ViewFlipper;

public class FlipperAutoActivity extends BaseActivity {
  String[] items = { "lorem", "ipsum", "dolor", "sit", "amet",
                     "consectetuer", "adipiscing", "elit",
                     "morbi", "vel", "ligula", "vitae",
                     "arcu", "aliquet", "mollis", "etiam",
                     "vel", "erat", "placerat", "ante",
                     "porttitor", "sodales", "pellentesque",
                     "augue", "purus" };
  Listener listener = new Listener();

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_flipper_auto);
    super.createDrawer();
    ActionBar aBar = getSupportActionBar();
    if (aBar != null)
      aBar.setTitle(R.string.act4_name);

    ViewFlipper flipper=(ViewFlipper)findViewById(R.id.vf_details);
    flipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.push_left_in));
    flipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.push_left_out));

    for (String item : items) {
      Button btn=new Button(this);
      btn.setText(item);
      btn.setOnClickListener(listener);
      flipper.addView(btn, new FrameLayout.LayoutParams(
          ViewGroup.LayoutParams.WRAP_CONTENT,
          ViewGroup.LayoutParams.WRAP_CONTENT,
          Gravity.CENTER));
    }
    flipper.setFlipInterval(2000);
    flipper.startFlipping();
  }

  private class Listener implements View.OnClickListener {
    @Override
    public void onClick(View v) {
      Toast.makeText(FlipperAutoActivity.this, "Button clicked:\n" + ((Button)v).getText(), Toast.LENGTH_LONG).show();
    }
  }
}


