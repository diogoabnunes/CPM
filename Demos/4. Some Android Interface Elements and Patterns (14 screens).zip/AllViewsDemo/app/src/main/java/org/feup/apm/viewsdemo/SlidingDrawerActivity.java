package org.feup.apm.viewsdemo;

import android.os.Bundle;
import androidx.appcompat.app.ActionBar;

public class SlidingDrawerActivity extends BaseActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_sliding_drawer);
    super.createDrawer();
    ActionBar aBar = getSupportActionBar();
    if (aBar != null)
      aBar.setTitle(R.string.act2_name);
  }
}
