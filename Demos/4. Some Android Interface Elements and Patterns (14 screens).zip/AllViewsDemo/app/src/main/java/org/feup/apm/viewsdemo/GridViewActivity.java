package org.feup.apm.viewsdemo;

import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.TextView;

public class GridViewActivity extends BaseActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    final TextView selection;
    final String[] items={"lorem", "ipsum", "dolor", "sit", "amet",
        "consectetuer", "adipiscing", "elit", "morbi", "vel",
        "ligula", "vitae", "arcu", "aliquet", "mollis",
        "etiam", "vel", "erat", "placerat", "ante",
        "porttitor", "sodales", "pellentesque", "augue", "purus"};

    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_grid_view);
    super.createDrawer();
    ActionBar aBar = getSupportActionBar();
    if (aBar != null)
      aBar.setTitle(R.string.act6_name);

    selection=(TextView)findViewById(R.id.gvselection);
    GridView g=(GridView) findViewById(R.id.grid);
    g.setAdapter(new ArrayAdapter<String>(this, R.layout.cell, items));
    g.setOnItemClickListener(new AdapterView.OnItemClickListener() {
      @Override
      public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
        selection.setText(items[position]);
      }
    });
  }
}
