package org.feup.apm.viewsdemo;

import android.graphics.Color;
import android.os.Bundle;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.ActionBar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SnackBarActivity extends BaseActivity {
  private CoordinatorLayout coordinatorLayout;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    Button btnSimpleSnackbar, btnActionCallback, btnCustomView;
    FloatingActionButton fab;

    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_snack_bar);
    super.createDrawer();
    ActionBar aBar = getSupportActionBar();
    if (aBar != null)
      aBar.setTitle(R.string.act11_name);

    coordinatorLayout = (CoordinatorLayout) findViewById(R.id.coordinatorLayout);

    fab = (FloatingActionButton) findViewById(R.id.fab);
    fab.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        Snackbar sb = Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG).setAction("Action", null);
        View sbView = sb.getView();
        sbView.setBackgroundResource(R.color.colorPrimary);
        sb.show();
      }
    });

    btnSimpleSnackbar = (Button) findViewById(R.id.btnSimpleSnackbar);
    btnActionCallback = (Button) findViewById(R.id.btnActionCallback);
    btnCustomView = (Button) findViewById(R.id.btnCustomSnackbar);

    btnSimpleSnackbar.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        Snackbar snackbar = Snackbar
            .make(coordinatorLayout, "Welcome to AndroidHive", Snackbar.LENGTH_LONG);
        View sbView = snackbar.getView();
        sbView.setBackgroundResource(R.color.colorPrimaryDark);
        snackbar.show();
      }
    });

    btnActionCallback.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        Snackbar snackbar = Snackbar
            .make(coordinatorLayout, "Message is deleted", Snackbar.LENGTH_LONG)
            .setAction("UNDO", new View.OnClickListener() {
              @Override
              public void onClick(View view) {
                Snackbar snackbar1 = Snackbar.make(coordinatorLayout, "Message is restored!", Snackbar.LENGTH_SHORT);
                View sbView = snackbar1.getView();
                sbView.setBackgroundResource(R.color.colorAccent);
                snackbar1.show();
              }
            });
        View sbView = snackbar.getView();
        sbView.setBackgroundResource(R.color.colorPrimaryDark);
        snackbar.show();
      }
    });

    btnCustomView.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        Snackbar snackbar = Snackbar
            .make(coordinatorLayout, "No internet connection!", Snackbar.LENGTH_LONG)
            .setAction("RETRY", new View.OnClickListener() {
              @Override
              public void onClick(View view) {
                Toast.makeText(SnackBarActivity.this, "RETRY clicked!", Toast.LENGTH_SHORT).show();
              }
            });

        // Changing message text color
        snackbar.setActionTextColor(Color.RED);

        // Changing action button text color
        View sbView = snackbar.getView();
        TextView textView = sbView.findViewById(R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);
        sbView.setBackgroundResource(R.color.colorPrimaryDark);
        snackbar.show();
      }
    });
  }
}
