package org.feup.apm.viewsdemo;

import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import android.view.View;
import android.widget.Button;
import android.widget.ViewFlipper;

public class FlipperActivity extends BaseActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_flipper);
    super.createDrawer();
    ActionBar aBar = getSupportActionBar();
    if (aBar != null)
      aBar.setTitle(R.string.act3_name);

    final ViewFlipper flipper=(ViewFlipper)findViewById(R.id.details);
    Button btn=(Button)findViewById(R.id.flip_me);

    btn.setOnClickListener(new View.OnClickListener() {
      public void onClick(View view) {
        flipper.showNext();
      }
    });
  }
}
