package org.feup.apm.viewsdemo;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.ViewGroup;
import android.widget.TextView;

public class RecyclerActivity extends BaseActivity implements RowHolder.OnClickedRowListener {
  private final String[] items={"lorem", "ipsum", "dolor", "sit", "amet",
      "consectetuer", "adipiscing", "elit", "morbi", "vel",
      "ligula", "vitae", "arcu", "aliquet", "mollis",
      "etiam", "vel", "erat", "placerat", "ante",
      "porttitor", "sodales", "pellentesque", "augue", "purus"};
  private ItemAdapter adapter;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_recycler);
    super.createDrawer();
    ActionBar aBar = getSupportActionBar();
    if (aBar != null)
      aBar.setTitle(R.string.act13_name);
    RecyclerView rv = findViewById(R.id.rcview);
    rv.setHasFixedSize(true);
    rv.setLayoutManager(new LinearLayoutManager(this));
    rv.setAdapter(adapter = new ItemAdapter(this, items));
  }

  @Override
  public void onRowClicked(int position) {
    ((TextView)findViewById(R.id.tv_selection)).setText(adapter.getItem(position));
  }

  class ItemAdapter extends RecyclerView.Adapter<RowHolder> {
    Context context;
    String[] list;

    ItemAdapter(Context context, String[] items) {
      this.context = context;
      list = items;
    }

    @Override
    public @NonNull RowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
      return new RowHolder(context, getLayoutInflater().inflate(R.layout.rcrow, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RowHolder holder, int position) {
      holder.bindData(list[position]);
    }

    @Override
    public int getItemCount() {
      return list.length;
    }

    public String getItem(int pos) {
      return list[pos];
    }
  }
}
