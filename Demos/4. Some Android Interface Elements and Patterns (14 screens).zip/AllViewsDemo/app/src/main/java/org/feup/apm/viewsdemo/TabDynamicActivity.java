package org.feup.apm.viewsdemo;

import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import android.view.View;
import android.widget.AnalogClock;
import android.widget.Button;
import android.widget.TabHost;

public class TabDynamicActivity extends BaseActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_tab_dynamic);
    super.createDrawer();
    ActionBar aBar = getSupportActionBar();
    if (aBar != null)
      aBar.setTitle(R.string.act9_name);

    final TabHost tabs = (TabHost)findViewById(R.id.tabhost2);

    tabs.setup();

    TabHost.TabSpec spec;

    spec = tabs.newTabSpec("buttontab");
    spec.setContent(R.id.buttontab);
    spec.setIndicator("Button");
    tabs.addTab(spec);

    Button btn=(Button)tabs.getCurrentView().findViewById(R.id.buttontab);

    btn.setOnClickListener(new View.OnClickListener() {
      public void onClick(View view) {
        TabHost.TabSpec spec;

        spec = tabs.newTabSpec("tag1");
        spec.setContent(new TabHost.TabContentFactory() {
          public View createTabContent(String tag) {
            return(new AnalogClock(TabDynamicActivity.this));
          }
        });
        spec.setIndicator("Clock");
        tabs.addTab(spec);
      }
    });
  }
}
