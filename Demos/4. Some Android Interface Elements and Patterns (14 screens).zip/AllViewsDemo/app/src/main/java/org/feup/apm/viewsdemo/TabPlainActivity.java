package org.feup.apm.viewsdemo;

import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import android.view.View;
import android.widget.TabHost;
import android.widget.Toast;

public class TabPlainActivity extends BaseActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_tab_plain);
    super.createDrawer();
    ActionBar aBar = getSupportActionBar();
    if (aBar != null)
      aBar.setTitle(R.string.act8_name);

    TabHost tabs=(TabHost)findViewById(R.id.tabhost1);
    tabs.setup();

    TabHost.TabSpec spec;

    spec=tabs.newTabSpec("tag1");
    spec.setContent(R.id.tab1);
    spec.setIndicator("Clock");
    tabs.addTab(spec);

    spec=tabs.newTabSpec("tag2");
    spec.setContent(R.id.tab2);
    spec.setIndicator("Button");
    tabs.addTab(spec);

    findViewById(R.id.tab2).setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        Toast.makeText(TabPlainActivity.this, "Button clicked!", Toast.LENGTH_LONG).show();
      }
    });
  }
}
