package org.feup.apm.viewsdemo;

import android.content.Intent;
import android.content.res.Configuration;
import androidx.annotation.NonNull;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class BaseActivity extends AppCompatActivity implements ListView.OnItemClickListener {
  private DrawerLayout mDrawerLayout;
  private ListView mDrawerList;
  private ActionBarDrawerToggle mDrawerToggle;

  protected void createDrawer() {
    // options and icon ids should be in equal number
    String[] options = getResources().getStringArray(R.array.options_array);
       // sample stock (Android) icons
    int[] icons = {
        android.R.drawable.ic_menu_edit,
        android.R.drawable.ic_menu_camera,
        android.R.drawable.ic_menu_compass,
        android.R.drawable.ic_menu_manage,
        android.R.drawable.ic_menu_info_details,
        android.R.drawable.ic_menu_crop,
        android.R.drawable.ic_menu_day,
        android.R.drawable.ic_menu_call,
        android.R.drawable.ic_menu_directions,
        android.R.drawable.ic_menu_gallery,
        android.R.drawable.ic_menu_help,
        android.R.drawable.ic_menu_agenda,
        android.R.drawable.ic_menu_month
    };

    mDrawerLayout = findViewById(R.id.drawer_layout);

    mDrawerList = findViewById(R.id.left_drawer);
    mDrawerList.setAdapter(new ItemsAdapter(options, icons));
    mDrawerList.setOnItemClickListener(this);

    mDrawerToggle = new ActionBarDrawerToggle(
        this,         // host Activity
        mDrawerLayout,       // DrawerLayout object
        R.string.app_name,        // "open drawer" description for accessibility
        R.string.app_name         // "close drawer" description for accessibility
    );
    mDrawerLayout.addDrawerListener(mDrawerToggle);

    ActionBar aBar = getSupportActionBar();
    if (aBar != null) {
      aBar.setDisplayHomeAsUpEnabled(true);
      aBar.setHomeButtonEnabled(true);
    }
  }
  /* the method for OnItemClickListener */
  @Override
  public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
    Intent intent = null;
    switch (position) {
      case 0:
        intent = new Intent(this, ChronoActivity.class);
        break;
      case 1:
        intent = new Intent(this, SlidingDrawerActivity.class);
        break;
      case 2:
        intent = new Intent(this, FlipperActivity.class);
        break;
      case 3:
        intent = new Intent(this, FlipperAutoActivity.class);
        break;
      case 4:
        intent = new Intent(this, ListViewActivity.class);
        break;
      case 5:
        intent = new Intent(this, GridViewActivity.class);
        break;
      case 6:
        intent = new Intent(this, ProgressActivity.class);
        break;
      case 7:
        intent = new Intent(this, TabPlainActivity.class);
        break;
      case 8:
        intent = new Intent(this, TabDynamicActivity.class);
        break;
      case 9:
        intent = new Intent(this, TabActionActivity.class);
        break;
      case 10:
        intent = new Intent(this, SnackBarActivity.class);
        break;
      case 11:
        intent = new Intent(this, SwipeActivity.class);
        break;
      case 12:
        intent = new Intent(this, RecyclerActivity.class);
        break;
    }
    mDrawerLayout.closeDrawer(mDrawerList);
    startActivity(intent);
    if (!(this instanceof MainActivity))
      finish();
  }

  /* required by ActionBarDrawerToggle */
  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    return mDrawerToggle.onOptionsItemSelected(item);
  }

  /* required by ActionBarDrawerToggle */
  @Override
  protected void onPostCreate(Bundle savedInstanceState) {
    super.onPostCreate(savedInstanceState);
    mDrawerToggle.syncState();
  }

  /* required by ActionBarDrawerToggle */
  @Override
  public void onConfigurationChanged(Configuration newConfig) {
    super.onConfigurationChanged(newConfig);
    mDrawerToggle.onConfigurationChanged(newConfig);
  }

  /* internal class as a custom adapter for displaying items on the drawer list */
  private class ItemsAdapter extends ArrayAdapter<String> {
    String[] names;
    int[] iconIds;

    ItemsAdapter(String[] options, int[] icons) {
      super(BaseActivity.this, R.layout.drawer_list_item, options);
      names = options;
      iconIds = icons;
    }

    @Override
    public @NonNull View getView(int position, View convertView, @NonNull ViewGroup parent) {
      View row = convertView;
      if (row == null) {
        row = getLayoutInflater().inflate(R.layout.drawer_list_item, parent, false);
      }
      ((TextView) row.findViewById(R.id.item)).setText(names[position]);  // item name
      ((ImageView) row.findViewById(R.id.icon)).setImageResource(iconIds[position]); // item icon
      return row;
    }
  }
}
