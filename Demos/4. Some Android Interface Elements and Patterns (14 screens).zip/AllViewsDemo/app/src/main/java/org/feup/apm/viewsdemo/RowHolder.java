package org.feup.apm.viewsdemo;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class RowHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
  public interface OnClickedRowListener {
    void onRowClicked(int position);
  }

  private TextView label, size;
  private ImageView icon;
  private String template;
  private Context context;

  RowHolder(Context context, View row) {
    super(row);
    label = row.findViewById(R.id.label);
    size = row.findViewById(R.id.size);
    icon = row.findViewById(R.id.icon);
    template = size.getContext().getString(R.string.sz_template);
    row.setOnClickListener(this);
    this.context = context;
  }

  @Override
  public void onClick(View v) {
    if (context instanceof OnClickedRowListener)
      ((OnClickedRowListener) context).onRowClicked(getAdapterPosition());
  }

  void bindData(String word) {
    label.setText(word);
    size.setText(String.format(template, word.length()));
    if (word.length() > 4)
      icon.setImageResource(android.R.drawable.ic_delete);
    else
      icon.setImageResource(android.R.drawable.ic_input_add);
  }
}

