package org.feup.apm.viewsdemo;

import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import androidx.legacy.app.FragmentStatePagerAdapter;

public class MyPagerAdapter extends FragmentStatePagerAdapter {
  MyPagerAdapter(FragmentManager fm) {
    super(fm);
  }

  @Override
  public Fragment getItem(int i) {
    Fragment fragment = new MyFragment();
    Bundle args = new Bundle();
    args.putInt(MyFragment.ARG_OBJECT, i + 1); // Our object is just an integer
    fragment.setArguments(args);
    return fragment;
  }

  // For this example, we have a 100-object collection.
  @Override
  public int getCount() {
    return 100;
  }

  // A title for the viewed object in the collection
  @Override
  public String getPageTitle(int position) {
    return ("page " + (position+1));
  }
}
