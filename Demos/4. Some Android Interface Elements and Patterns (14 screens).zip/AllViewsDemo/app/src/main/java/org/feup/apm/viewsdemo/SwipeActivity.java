package org.feup.apm.viewsdemo;

import android.os.Bundle;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.ActionBar;
import android.view.View;

public class SwipeActivity extends BaseActivity {
  /**
   * The PagerAdapter provides fragments representing
   * each object in a collection. We use a FragmentStatePagerAdapter
   * derivative, which will destroy and re-create fragments as needed, saving and restoring their
   * state in the process. This is important to conserve memory and is a best practice when
   * allowing navigation between objects in a potentially large collection.
   */
  MyPagerAdapter mPagerAdapter;

  /**
   * The {android.support.v4.view.ViewPager} that will display the object collection.
   */
  ViewPager mViewPager;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_swipe);
    super.createDrawer();
    ActionBar aBar = getSupportActionBar();
    if (aBar != null)
      aBar.setTitle(R.string.act12_name);

    mPagerAdapter = new MyPagerAdapter(getFragmentManager());

    // Set up the ViewPager, attaching the adapter.
    mViewPager = (ViewPager) findViewById(R.id.pager);
    mViewPager.setAdapter(mPagerAdapter);
    findViewById(R.id.bt_first).setOnClickListener((View v) -> mViewPager.setCurrentItem(0, true));
    findViewById(R.id.bt_last).setOnClickListener((View v) -> mViewPager.setCurrentItem(mPagerAdapter.getCount()-1));
  }
}
