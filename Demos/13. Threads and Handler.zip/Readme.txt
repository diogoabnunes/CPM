ColorAnim Demo
==============

This demo creates 3 worker threads that continously determine randomly the color of a circle
in the user interface.
The circle id and the color are then passed to the main (UI) thread, using a message and a
Handler object that was created and passed to the thread, when it was created in the Activity.
When the UI thread gets, in its loop, the message, it changes the corresponding circle color.
It then procedes to the next message.
