package org.feup.apm.calc1;

import java.text.DecimalFormat;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class CalculatorActivity extends AppCompatActivity {
  private double memory = 0.0;
  private EditText data1 = null;
  private EditText data2 = null;
  private TextView result = null;

  /** Called when the activity is first created. */
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);
    data1 = (EditText) findViewById(R.id.editText1);
    data2 = (EditText) findViewById(R.id.editText2);
    result = (TextView) findViewById(R.id.result);
    if (savedInstanceState != null)
      memory = savedInstanceState.getDouble("mem", 0.0);
  }
  
  @Override
  public void onSaveInstanceState(Bundle b) {
    b.putDouble("mem", memory);
    super.onSaveInstanceState(b);
  }
  
  /** Button listeners */
  public void PlusOnClick(View v) {
    DecimalFormat df = new DecimalFormat("#.###");
    double a1 = Double.parseDouble(data1.getText().toString());
    double a2 = Double.parseDouble(data2.getText().toString());
    result.setText(df.format(a1+a2));
  }
  
  public void MinusOnClick(View v) {
    DecimalFormat df = new DecimalFormat("#.###");
    double a1 = Double.parseDouble(data1.getText().toString());
    double a2 = Double.parseDouble(data2.getText().toString());
    result.setText(df.format(a1-a2));
  }
  
  public void MultiplyOnClick(View v) {
    DecimalFormat df = new DecimalFormat("#.###");
    double a1 = Double.parseDouble(data1.getText().toString());
    double a2 = Double.parseDouble(data2.getText().toString());
    result.setText(df.format(a1*a2));
  }
  
  public void DivideOnClick(View v) {
    DecimalFormat df = new DecimalFormat("#.###");
    double a1 = Double.parseDouble(data1.getText().toString());
    double a2 = Double.parseDouble(data2.getText().toString());
    result.setText(df.format(a1/a2));
  }
  
  public void StoreOnClick(View v) {
    if (result != null)
      memory = Double.parseDouble(result.getText().toString());
    else
      memory = 0.0;
  }
  
  public void RecallOnClick(View v) {
    DecimalFormat df = new DecimalFormat("#.###");
    data1.setText(df.format(memory));
  }
}