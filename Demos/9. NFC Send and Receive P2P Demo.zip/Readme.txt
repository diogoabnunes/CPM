This app allows to send and receive text messages using two phones with NFC
and the same app installed.
The messages are transmitted using the NFC P2P mode (Android beam).
Both NFC and Android Beam should be enabled in settings, before the app
could be used.
After API 29 this functionality could not be present in devices designed for
Android Q or R (it became an optional feature in Android phones with NFC).

