package org.feup.apm.nfcsendreceive;

import android.app.Application;

public class NfcApp extends Application {
  public String reply = "";
}
