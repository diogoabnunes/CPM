package pt.up.feup.cpm.weatherapp.weather_forecast

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
